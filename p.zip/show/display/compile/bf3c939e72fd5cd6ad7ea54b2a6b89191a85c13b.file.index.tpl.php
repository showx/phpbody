<?php /* Smarty version Smarty-3.1.14, created on 2014-03-03 21:26:54
         compiled from "/Library/WebServer/Documents/phpg/phpbody/templates/default/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10245748485314831ee4df74-32257518%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bf3c939e72fd5cd6ad7ea54b2a6b89191a85c13b' => 
    array (
      0 => '/Library/WebServer/Documents/phpg/phpbody/templates/default/index.tpl',
      1 => 1392207517,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10245748485314831ee4df74-32257518',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.14',
  'unifunc' => 'content_5314831ee85072_99587544',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5314831ee85072_99587544')) {function content_5314831ee85072_99587544($_smarty_tpl) {?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>PHPBODY</title>
<link rel="stylesheet" type="text/css" href="/static/css/normal.css" title="default"/>
</head>

<body>
<div id="con">
<div id="msg">
<p id="pp">PHPBODY企业建站系统，欢迎使用下载。<span><a href="mailto:9448923@qq.com">联系作者</a>
</span></p>
<p id="pp"></p>
</div>
</div>

</body>
</html>
<?php }} ?>