<?php
if(!defined('BODY')){exit();}
/**
 * 数据库crud操作类
 * 增删改操作
 * Author show
 * copyright phpbody (www.phpbody.com)
 */

