<?php
if(!defined('BODY')){exit();}
/**
 * sphinx搜索类
 * Author show
 * copyright phpbody (www.phpbody.com)
 */
