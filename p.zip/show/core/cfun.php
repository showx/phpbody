<?php
/*
 * 常用函数库 
 * (有些常用的函数直接使用比较方便)
 * Author show 
 * copry right PHPBODY (www.phpbody.com)
 */
function b()
{
    echo "<br/>";
}
function dbug($var)
{
	form::sbug($var);
}
function go($c,$a)
{
	form::go($c,$a);
}
?>