<?php
if(!defined('BODY')){exit();}
Class lists extends base{
    public function index()
    {
        
    }
}