<?php
if(!defined('BODY')){exit();}
/**
* 应用辅助
* Author show
* copyright phpbody (www.phpbody.com)
*/
Class app extends base{

    public function index()
    {
    	
    }
}