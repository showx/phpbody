<?php
if(!defined('BODY')){exit();}
/**
 * 基类
 * Author show
 * copyright phpbody (www.phpbody.com)
 */
Class base{
    public function __construct() {
        
    }
}