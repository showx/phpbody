<?php
/**
 * 常用config
 */
$GLOBALS['uploads']['temp'] = 'uploads';

$GLOBALS['debug']['url'] = true;

$GLOBALS['debug']['page'] = true;
?>
