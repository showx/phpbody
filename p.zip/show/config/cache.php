<?php
$GLOBALS['cache']['type'] = '';
$GLOBALS['cache']['host'] = '';
$GLOBALS['cache']['sql'] = false;
?>
