<?php
/*
 * 数据库相关配置
 */
//数据库地址
$GLOBALS['db']['host'] = '127.0.0.1'; 
//数据库用户名
$GLOBALS['db']['user'] = 'root';
//数据库
$GLOBALS['db']['databases'] = 'PHPBODY';
//数据库密码
$GLOBALS['db']['pass'] = 'root';

$GLOBALS['db']['pre'] =  'show_';
?>
