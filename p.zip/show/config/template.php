<?php
/*
 * 模板配置
 */

define("TEMPLATES","default");

define("templatelib",PHPBODY."/show/display/libs");

define("template_dir",PHPBODY."/templates/".TEMPLATES);

define("compile_dir",PHPBODY."/show/display/compile");

define("config_dir",PHPBODY."/show/display/config");

define("cache_dir",PHPBODY."/show/display/cache");

define("left_delimiter","<{");

define("right_delimiter","}>");

?>
